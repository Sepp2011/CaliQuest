let unlocked=+(localStorage.cqUnlocked||1);
const root=document.getElementById('levels');
function save(){localStorage.cqUnlocked=unlocked;}
function render(){
root.innerHTML='';
LEVELS.forEach(l=>{
 const d=document.createElement('div');
 d.className='level'+(l.id>unlocked?' locked':'');
 d.innerHTML=`<h3>${l.boss?'👑 ':''}Level ${l.id}</h3>`;
 if(l.id<=unlocked){
   const b=document.createElement('button');
   b.textContent='Abschließen';
   b.onclick=()=>{if(l.id===unlocked&&unlocked<30){unlocked++;save();render();alert('Level '+unlocked+' freigeschaltet!')}};
   d.appendChild(b);
 }else{
   d.innerHTML+='<p>🔒 Gesperrt</p>';
 }
 root.appendChild(d);
});
}
render();